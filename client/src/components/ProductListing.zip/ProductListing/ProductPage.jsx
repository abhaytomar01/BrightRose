import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";

const ProductDetails = () => {
  const { productId } = useParams(); // ✅ match route param
  const [product, setProduct] = useState(null);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const res = await axios.get(`http://localhost:8080/api/v1/product/${productId}`);
        if (res.data?.success) setProduct(res.data.product);
        else setError("Product not found");
      } catch (err) {
        console.error("Error fetching product:", err);
        setError("Product not found or server error");
      }
    };
    fetchProduct();
  }, [productId]);

  if (error)
    return (
      <div className="flex flex-col justify-center items-center h-screen text-gray-600 text-lg">
        <p>{error}</p>
        <button
          onClick={() => navigate(-1)}
          className="mt-4 px-6 py-2 bg-black text-white rounded-lg"
        >
          Go Back
        </button>
      </div>
    );

  if (!product)
    return (
      <div className="flex justify-center items-center h-screen text-gray-500 text-lg">
        Loading product details...
      </div>
    );

  return (
    <div className="min-h-screen bg-white text-gray-800 px-6 md:px-20 py-10">
      <button
        onClick={() => navigate(-1)}
        className="text-sm text-gray-600 mb-6 hover:text-black"
      >
        ← Back
      </button>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        {/* Product Image */}
        <div className="flex justify-center items-center bg-gray-50 rounded-2xl p-6">
          <img
            src={product.images?.[0]?.url || product.images?.[0] || "/placeholder.jpg"}
            alt={product.name}
            className="object-cover w-full h-[500px] rounded-xl"
          />
        </div>

        {/* Product Info */}
        <div>
          <h1 className="text-3xl font-semibold mb-3">{product.name}</h1>
          <p className="text-gray-600 mb-4">{product.shortDescription}</p>

          <p className="text-2xl font-bold text-gray-900 mb-6">
            ₹{product.price}
          </p>

          <button className="bg-black text-white px-8 py-3 rounded-lg hover:bg-gray-800 transition">
            Add to Cart
          </button>

          <div className="mt-10 border-t border-gray-200 pt-6">
            <h2 className="text-lg font-semibold mb-2">Product Description</h2>
            <p className="text-gray-700 leading-relaxed">
              {product.longDescription ||
                "This is an elegant handmade product crafted from fine materials with timeless design."}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetails;
