/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */
import StarIcon from "@mui/icons-material/Star";
import FavoriteIcon from "@mui/icons-material/Favorite";
import { Link } from "react-router-dom";
import { getDiscount } from "../../utils/functions";
import ScrollToTopOnRouteChange from "../../utils/ScrollToTopOnRouteChange";
import { toast } from "react-toastify";
import axios from "axios";
import { useAuth } from "../../context/auth";

const Product = ({
  _id,
  images,
  name,
  ratings,
  numOfReviews,
  price,
  discountPrice,
  wishlistItems,
  setWishlistItems,
}) => {
  const { auth, isAdmin } = useAuth();

  const itemInWishlist = wishlistItems?.some((itemId) => itemId === _id);

  const updateWishlistUI = (add) => {
    setWishlistItems((prev) =>
      add ? [...prev, _id] : prev.filter((item) => item !== _id)
    );
  };

  const addToWishlistHandler = async () => {
    const type = itemInWishlist ? "remove" : "add";
    try {
      updateWishlistUI(type === "add");

      await axios.post(
        `${import.meta.env.VITE_SERVER_URL}/api/v1/user/update-wishlist`,
        { productId: _id, type },
        { headers: { Authorization: auth.token } }
      );
    } catch (error) {
      console.error(error);
      toast.error("Something went wrong! Please try again later.", {
        toastId: "error",
      });
      updateWishlistUI(type !== "add");
    }
  };

  return (
    <>
      <ScrollToTopOnRouteChange />
      <div className="relative w-full max-w-[220px] sm:max-w-[260px] bg-white rounded-xl shadow-sm hover:shadow-md transition-all duration-300 mx-auto sm:mx-0 overflow-hidden group">
        {/* Wishlist Button */}
        {!isAdmin && (
          <button
            onClick={addToWishlistHandler}
            className={`absolute top-2 right-2 z-10 p-1.5 rounded-full bg-white shadow-sm hover:shadow-md transition ${
              itemInWishlist ? "text-red-500" : "text-gray-400 hover:text-red-500"
            }`}
          >
            <FavoriteIcon sx={{ fontSize: 20 }} />
          </button>
        )}

        {/* Product Image */}
        <Link to={`/product/${_id}`}>
          <div className="w-full h-52 sm:h-60 bg-gray-50 flex items-center justify-center">
            <img
              draggable="false"
              src={images && (images[0]?.url || images[0])}
              alt={name}
              className="object-contain w-40 h-44 sm:w-48 sm:h-52 transition-transform duration-300 group-hover:scale-105"
            />
          </div>
        </Link>

        {/* Product Info */}
        <div className="p-3 sm:p-4 flex flex-col gap-2">
          {/* Product Name */}
          <h2 className="text-sm sm:text-base font-medium text-gray-800 line-clamp-2 leading-snug group-hover:text-blue-600 transition">
            {name}
          </h2>

          {/* Rating Section */}
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1 bg-green-500 text-white text-xs px-1.5 py-0.5 rounded">
              {ratings?.toFixed(1) || 4.5}
              <StarIcon sx={{ fontSize: 14 }} />
            </span>
            <span className="text-xs text-gray-500">
              ({numOfReviews || 0})
            </span>
            {/* <img
              src="https://static-assets-web.flixcart.com/fk-p-linchpin-web/fk-cp-zion/img/fa_62673a.png"
              alt="assured"
              className="w-12 h-4 ml-auto object-contain"
            /> */}
          </div>

          {/* Price Section */}
          <div className="flex items-center gap-2 mt-1">
            <span className="text-sm sm:text-base font-semibold text-gray-900">
              ₹{discountPrice?.toLocaleString() || price}
            </span>
            <span className="text-xs text-gray-400 line-through">
              ₹{price?.toLocaleString()}
            </span>
            <span className="text-xs text-green-600 font-medium">
              {getDiscount(price, discountPrice)}% off
            </span>
          </div>
        </div>
      </div>
    </>
  );
};

export default Product;
