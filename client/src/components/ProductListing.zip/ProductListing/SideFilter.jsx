import { useState } from "react";
import { FaFilter } from "react-icons/fa";

const SideFilter = ({ setFilters }) => {
  const [isMobileFilterOpen, setIsMobileFilterOpen] = useState(false);

  const [filters, updateFilters] = useState({
    weaves: [],
    styles: [],
    price: [500, 5000],
    colors: [],
    sizes: [],
    sortBy: "newest",
  });

  const weaves = [
    "Kanjeevaram",
    "Kantha",
    "Shibori",
    "Tanchoi",
    "Benarasi",
    "Kadwa",
    "Pochampally Ikat",
    "Gadwal",
    "Uppada",
    "Jamdani",
  ];

  const styles = [
    "Coats & Blazers",
    "Skirts & Pants",
    "Saree",
    "Dresses",
    "Corsets & Tops",
  ];

  const colors = [
    { name: "Red", code: "#e74c3c" },
    { name: "Blue", code: "#3498db" },
    { name: "Green", code: "#27ae60" },
    { name: "Black", code: "#000000" },
    { name: "White", code: "#ffffff" },
    { name: "Beige", code: "#f5f5dc" },
  ];

  const sizes = ["XS", "S", "M", "L", "XL"];

  const handleCheckbox = (type, value) => {
    updateFilters((prev) => {
      const newValues = prev[type].includes(value)
        ? prev[type].filter((v) => v !== value)
        : [...prev[type], value];

      const updated = { ...prev, [type]: newValues };
      setFilters(updated);
      return updated;
    });
  };

  const handlePriceChange = (e, index) => {
    const newPrice = [...filters.price];
    newPrice[index] = Number(e.target.value);
    updateFilters((prev) => {
      const updated = { ...prev, price: newPrice };
      setFilters(updated);
      return updated;
    });
  };

  const handleSortChange = (e) => {
    const updated = { ...filters, sortBy: e.target.value };
    updateFilters(updated);
    setFilters(updated);
  };

  return (
    <>
      {/* Mobile Filter Toggle */}
      <button
        onClick={() => setIsMobileFilterOpen(!isMobileFilterOpen)}
        className="md:hidden flex items-center gap-2 px-4 py-2 text-sm font-semibold bg-gray-100 rounded-md border mb-3 ml-4 mt-2"
      >
        <FaFilter /> Filters
      </button>

      {/* Filter Sidebar */}
      <aside
        className={`${
          isMobileFilterOpen ? "block" : "hidden"
        } md:block bg-white md:sticky top-28 md:h-fit shadow-sm md:shadow-none rounded-xl p-5 md:w-64 w-full z-40 absolute md:static left-0 md:translate-x-0 transition-all duration-300`}
      >
        <h2 className="text-lg font-bold mb-4 border-b pb-2">Filter By</h2>

        {/* Weaves */}
        <div className="mb-5">
          <h3 className="font-semibold text-gray-700 mb-2">Weaves</h3>
          <ul className="space-y-2">
            {weaves.map((weave) => (
              <li key={weave}>
                <label className="flex items-center gap-2 text-sm cursor-pointer">
                  <input
                    type="checkbox"
                    checked={filters.weaves.includes(weave)}
                    onChange={() => handleCheckbox("weaves", weave)}
                    className="accent-black"
                  />
                  {weave}
                </label>
              </li>
            ))}
          </ul>
        </div>

        {/* Styles */}
        <div className="mb-5">
          <h3 className="font-semibold text-gray-700 mb-2">Style</h3>
          <ul className="space-y-2">
            {styles.map((style) => (
              <li key={style}>
                <label className="flex items-center gap-2 text-sm cursor-pointer">
                  <input
                    type="checkbox"
                    checked={filters.styles.includes(style)}
                    onChange={() => handleCheckbox("styles", style)}
                    className="accent-black"
                  />
                  {style}
                </label>
              </li>
            ))}
          </ul>
        </div>

        {/* Price Range */}
        <div className="mb-5">
          <h3 className="font-semibold text-gray-700 mb-2">Price Range (₹)</h3>
          <div className="flex items-center gap-2 text-sm">
            <input
              type="number"
              value={filters.price[0]}
              onChange={(e) => handlePriceChange(e, 0)}
              className="w-16 border rounded-md px-2 py-1"
            />
            <span>–</span>
            <input
              type="number"
              value={filters.price[1]}
              onChange={(e) => handlePriceChange(e, 1)}
              className="w-16 border rounded-md px-2 py-1"
            />
          </div>
        </div>

        {/* Colors */}
        <div className="mb-5">
          <h3 className="font-semibold text-gray-700 mb-2">Color</h3>
          <div className="flex flex-wrap gap-2">
            {colors.map((color) => (
              <div
                key={color.name}
                title={color.name}
                onClick={() => handleCheckbox("colors", color.name)}
                className={`w-6 h-6 rounded-full cursor-pointer border ${
                  filters.colors.includes(color.name)
                    ? "ring-2 ring-black"
                    : "ring-0"
                }`}
                style={{ backgroundColor: color.code }}
              />
            ))}
          </div>
        </div>

        {/* Sizes */}
        <div className="mb-5">
          <h3 className="font-semibold text-gray-700 mb-2">Size</h3>
          <div className="flex flex-wrap gap-2">
            {sizes.map((size) => (
              <button
                key={size}
                onClick={() => handleCheckbox("sizes", size)}
                className={`px-3 py-1 border rounded-md text-sm ${
                  filters.sizes.includes(size)
                    ? "bg-black text-white"
                    : "bg-white text-gray-700"
                }`}
              >
                {size}
              </button>
            ))}
          </div>
        </div>

        {/* Sort By */}
        <div>
          <h3 className="font-semibold text-gray-700 mb-2">Sort By</h3>
          <select
            value={filters.sortBy}
            onChange={handleSortChange}
            className="w-full border rounded-md px-3 py-2 text-sm"
          >
            <option value="newest">Newest</option>
            <option value="priceLowHigh">Price: Low → High</option>
            <option value="priceHighLow">Price: High → Low</option>
            <option value="aToZ">Name: A → Z</option>
            <option value="zToA">Name: Z → A</option>
          </select>
        </div>
      </aside>

      {/* Overlay for mobile */}
      {isMobileFilterOpen && (
        <div
          className="fixed inset-0 bg-black/40 md:hidden z-30"
          onClick={() => setIsMobileFilterOpen(false)}
        />
      )}
    </>
  );
};

export default SideFilter;
