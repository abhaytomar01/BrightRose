import productModel from "../../models/productModel.js";

const getFilteredProducts = async (req, res) => {
  try {
    const { category, color, size, sort } = req.query;

    // Build query dynamically
    const query = {};

    if (category && category !== "all") {
      query.category = category;
    }

    if (color && color !== "all") {
      query.color = color;
    }

    if (size && size !== "all") {
      query.size = size;
    }

    // Base query
    let productsQuery = productModel.find(query);

    // Sorting logic
    if (sort) {
      switch (sort) {
        case "price_asc":
          productsQuery = productsQuery.sort({ price: 1 });
          break;
        case "price_desc":
          productsQuery = productsQuery.sort({ price: -1 });
          break;
        case "newest":
          productsQuery = productsQuery.sort({ createdAt: -1 });
          break;
        case "top_rated":
          productsQuery = productsQuery.sort({ ratings: -1 });
          break;
        default:
          break;
      }
    }

    // Fetch products
    const products = await productsQuery.exec();

    res.status(200).json({
      success: true,
      count: products.length,
      products,
    });
  } catch (error) {
    console.error("Error fetching filtered products:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch filtered products",
    });
  }
};

export default getFilteredProducts;
